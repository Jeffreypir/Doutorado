-- lua/config/functions.lua
local M = {}

-- Função para executar o arquivo atual
function M.run_file()
    local filetype = vim.bo.filetype
    local filename = vim.fn.expand('%:p')
    local filename_no_ext = vim.fn.expand('%:r')

    local commands = {
        python = 'python3 ' .. filename,
        javascript = 'node ' .. filename,
        lua = 'lua ' .. filename,
        sh = 'bash ' .. filename,
        c = 'gcc ' .. filename .. ' -o ' .. filename_no_ext .. ' && ./' .. filename_no_ext,
        cpp = 'g++ ' .. filename .. ' -o ' .. filename_no_ext .. ' && ./' .. filename_no_ext,
        java = 'javac ' .. filename .. ' && java ' .. filename_no_ext,
        r = 'Rscript ' .. filename, 
        tex = 'pdflatex ' .. filename,
    }

    local command = commands[filetype]
    if type(command) == 'function' then
        command = command()
    end

    if command then
        vim.cmd('split | resize 15 | terminal ' .. command)
    else
        print('Tipo de arquivo não suportado ou comando inválido: ' .. filetype)
    end
end

-- Função para preencher placeholders
function M.fill_placeholders()
    local filename = vim.fn.expand('%:t:r')
    local lines = vim.api.nvim_buf_get_lines(0, 0, -1, false)
    local datetime = os.date('%Y-%m-%d %H:%M:%S')

    local has_placeholders = false
    for _, line in ipairs(lines) do
        if line:match('<%+name%+>') or line:match('<%+description%+>') then
            has_placeholders = true
            break
        end
    end

    if has_placeholders then
        local name = vim.fn.input('Nome do programa: ', filename)
        local description = vim.fn.input('Descrição: ')

        for i, line in ipairs(lines) do
            lines[i] = line:gsub('<%+name%+>', name)
                :gsub('<%+date%+>', datetime)
                :gsub('<%+update%+>', datetime)
                :gsub('<%+description%+>', description)
        end
    else
        for i, line in ipairs(lines) do
            if line:match('Update in:') then
                lines[i] = line:gsub('Update in: .+', 'Update in: ' .. datetime)
                break
            end
        end
    end

    vim.api.nvim_buf_set_lines(0, 0, -1, false, lines)
end

-- Função que adiciona definição dependendo do tipo de arquivo
function M.DefineSmart()
    local word = vim.fn.expand("<cword>")  -- pega a palavra sob o cursor
    if word == "" then
        print("Nenhuma palavra encontrada sob o cursor")
        return
    end

    -- Pergunta o valor ao usuário
    local value = vim.fn.input("Valor para " .. word .. ": ")
    if value == "" then
        print("Nenhum valor fornecido")
        return
    end

    local bufnr = vim.api.nvim_get_current_buf()
    local filetype = vim.bo.filetype  -- detecta o tipo de arquivo

    if filetype == "c" or filetype == "cpp" or filetype == "arduino" then
        -- procura a linha contendo "MACROS"
        local total_lines = vim.api.nvim_buf_line_count(bufnr)
        local insert_line = nil
        for i = 0, total_lines - 1 do
            local text = vim.api.nvim_buf_get_lines(bufnr, i, i+1, false)[1]
            if text:match("MACROS") then
                insert_line = i + 1  -- insere abaixo
                break
            end
        end
        if insert_line then
            vim.api.nvim_buf_set_lines(bufnr, insert_line, insert_line, false, {"#define " .. word .. " " .. value})
            print("Inserido: #define " .. word .. " " .. value .. " abaixo de MACROS")
        else
            print("Não encontrou a linha MACROS")
        end
    else
        -- Para outros arquivos, insere acima da linha atual
        local row = vim.fn.line(".") - 1
        vim.api.nvim_buf_set_lines(bufnr, row, row, false, {word .. " = " .. value})
        print("Inserido: " .. word .. " = " .. value .. " acima da linha atual")
    end
end

return M

