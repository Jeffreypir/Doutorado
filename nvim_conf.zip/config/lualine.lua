-- ===============================
-- Configuração do Lualine (Hack Nerd Font)
-- ===============================

require("lualine").setup({
    options = {
        theme = "onedark",  -- escolha aqui o tema
        icons_enabled = false,
        -- section_separators = { left = ">", right = "<" },
        component_separators = { left = "|", right = "|" },
    },
})

