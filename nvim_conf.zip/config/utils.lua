-- lua/config/utils.lua
local M = {}

function M.map_keys(mode, lhs, rhs, opts)
    if type(opts) ~= "table" then
        opts = {}
    end
    opts = vim.tbl_extend("force", { noremap = true, silent = true }, opts)
    vim.keymap.set(mode, lhs, rhs, opts)  -- agora aceita mode como tabela também
end

return M

