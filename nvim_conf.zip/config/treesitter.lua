-- lua/config/treesitter.lua

require("nvim-treesitter.configs").setup({
    -- Idiomas que você quer instalar
    ensure_installed = { "c", "cpp", "python", "javascript", "typescript", "lua", "rust", "r" },

    -- Habilita destaque de sintaxe avançado
    highlight = { enable = true },

    -- Habilita indentação automática inteligente
    indent = {
        enable = true,
        disable = {"python"},

    },
    -- Habilita fechamento/renomeação automática de tags (para HTML, XML, JSX)
    -- autotag = { enable = true },
})

