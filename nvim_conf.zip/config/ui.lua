-- lua/config/ui.lua
vim.opt.termguicolors = true
vim.cmd.colorscheme("jeffrey")


