-- lua/config/options

-- Alias para facilitar acesso a funções
local set = vim.opt       -- Para opções de configuração
local g = vim.g           -- Para variáveis globais
local cmd = vim.cmd       -- Para executar comandos do Vimscript


--------------------------------------------------------------------------------
--  Opções booleanas
-- Essas opções são simples liga/desliga (true/false)
--------------------------------------------------------------------------------
local bool_opts = {
    background    = 'dark',   -- Tema escuro
    showcmd       = true,     -- Mostra comandos parcialmente digitados
    showmatch     = true,     -- Destaca parênteses/chaves correspondentes
    ignorecase    = true,     -- Busca insensível a maiúsculas/minúsculas
    smartcase     = true,     -- Considera maiúsculas se houver letras maiúsculas na busca
    incsearch     = true,     -- Busca incremental
    autowrite     = true,     -- Salva automaticamente antes de certos comandos
    title         = true,     -- Mostra título da janela
    hls           = true,     -- Destaca resultados da busca
    number        = true,     -- Mostra números das linhas
    hid           = true,     -- Esconde buffers em vez de fechar
    ic            = true,     -- Busca ignorando maiúsculas/minúsculas
    showmode      = true,     -- Mostra o modo atual
    hlsearch      = true,     -- Destaca resultados da busca
    magic         = true,     -- Ativa padrões mágicos de busca
    breakindent   = true,     -- Mantém indentação em quebras de linha
    expandtab     = true,     -- Converte tabs em espaços
    backup        = true,     -- Habilita backup de arquivos
    splitright    = true,     -- Splits verticais abrem à direita
    splitbelow    = true,     -- Splits horizontais abrem abaixo
    wildmenu      = true,     -- Menu de autocompletar comandos
    autoread      = true,     -- Recarrega arquivos alterados externamente
    termguicolors = false,    -- Desativa cores verdadeiras no terminal
    ttyfast       = true,     -- Renderização mais rápida
    cursorline    = true,     -- Destaca linha atual
}

-- Loop para aplicar todas as opções booleanas
for k, v in pairs(bool_opts) do
    set[k] = v
end
-- Explicação: 'pairs' percorre cada chave e valor da tabela, aplicando a configuração
-- equivalente em 'vim.opt'. Isso evita múltiplos comandos repetitivos.

--------------------------------------------------------------------------------
-- Opções numéricas
-- Definem valores que são números
--------------------------------------------------------------------------------
local num_opts = {
    tabstop     = 4,  -- Quantos espaços uma tabulação representa
    shiftwidth  = 4,  -- Quantos espaços serão usados para recuos
}

-- Loop para aplicar opções numéricas
for k, v in pairs(num_opts) do
    set[k] = v
end
-- Explicação: igual ao loop anterior, mas para valores numéricos.

--------------------------------------------------------------------------------
--  Opções de string
-- Contêm configurações textuais, como modos de completamento
--------------------------------------------------------------------------------
local str_opts = {
    completeopt = "menu,menuone,noselect", -- Opções de autocompletar
    wildmode    = "longest,list",          -- Modo de autocompletar
}

-- Loop para aplicar opções de string
for k, v in pairs(str_opts) do
    set[k] = v
end

------------------------------------------------
-- Opções especiais (que precisam de métodos)
------------------------------------------------
set.iskeyword:append { "\\", "~" }  -- Adiciona caracteres especiais às palavras-chave

-----------------------------------------------------------------------

