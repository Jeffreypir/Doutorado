-- lua/config/lsp.lua


--------------------------------------------------------------------------------
-- Configuração Moderna de LSP (Neovim 0.11+)
-- Esta configuração utiliza a nova API `vim.lsp.config` e `vim.lsp.enable`
-- para inicializar todos os servidores de linguagem de forma segura.
-- Mantém suporte a autocompletar, linting, formatação e diagnósticos.
--------------------------------------------------------------------------------

-- 1️⃣ Capacidades adicionais para LSP com nvim-cmp
local cmp_ok, cmp_nvim_lsp = pcall(require, "cmp_nvim_lsp")
local capabilities = {}
if cmp_ok then
    capabilities = cmp_nvim_lsp.default_capabilities()
end

--------------------------------------------------------------------------------
-- 2️⃣ Tabela de configuração dos servidores LSP
-- Cada chave é o nome do servidor, e o valor contém suas opções específicas.
--------------------------------------------------------------------------------
local lsp_setup = {

    -- Markdown
    marksman = { capabilities = capabilities },

    -- LaTeX
    texlab = {
        capabilities = capabilities,
        settings = {
            texlab = {
                auxDirectory = "build",
                build = {
                    executable = "latexmk",
                    args = { "-pdf", "-interaction=nonstopmode", "-synctex=1", "%f" },
                    onSave = true,
                    forwardSearchAfter = true,
                },
                forwardSearch = {
                    executable = "sumatrapdf.exe",
                    args = { "--synctex-forward", "%l:1:%f", "%p" },
                },
                chktex = { onOpenAndSave = true },
                formatting = { command = "latexindent", args = { "-" } },
            },
        },
    },

    -- C / C++
    clangd = {
        capabilities = capabilities,
        cmd = { "clangd", "--background-index" },
        filetypes = { "c", "cpp", "arduino" },
        settings = {
            clangd = { fallbackFlags = { "-std=c++11" } },
        },
    },

    -- Python (Jedi)
    jedi_language_server = {
        capabilities = capabilities,
        cmd = { "jedi-language-server" },
        filetypes = { "python" },
        settings = {
            jedi = {
                diagnostics = { enable = true },
                workspace = {}, -- Configurações opcionais do workspace
            },
        },
    },

    -- TypeScript / JavaScript
    tsserver = { capabilities = capabilities },

    -- R (languageserver)
    r_language_server = {
        capabilities = capabilities,
        cmd = { "/usr/bin/R", "--no-echo", "-e", "languageserver::run()" },
        filetypes = { "r", "rmd", "quarto" },
        autostart = true,
        settings = {
            r = {
                lsp = {
                    rich_documentation = true,
                    diagnostics = true,
                    hover = true,
                },
            },
        },
        on_attach = function(_, _)
            vim.fn.setenv("R_LIBS_USER", os.getenv("HOME") .. "/r_libs")
        end,
    },

    -- Java
    jdtls = { capabilities = capabilities },

    -- Rust
    rust_analyzer = { capabilities = capabilities, settings = { ["rust-analyzer"] = {} } },

    -- Emmet (HTML, CSS, React, etc.)
    emmet_language_server = {
        capabilities = capabilities,
        filetypes = {
            "css", "eruby", "html", "javascript", "javascriptreact",
            "less", "sass", "scss", "pug", "typescriptreact"
        },
        init_options = {
            showAbbreviationSuggestions = true,
            showExpandedAbbreviation = "always",
            showSuggestionsAsSnippets = false,
        },
    },
}

--------------------------------------------------------------------------------
-- 3️⃣ Inicialização automática usando a nova API
-- `vim.lsp.config()` define a configuração de cada servidor
-- `vim.lsp.enable()` ativa o servidor para seus filetypes
--------------------------------------------------------------------------------
for server, config in pairs(lsp_setup) do
    vim.lsp.config(server, config)
    vim.lsp.enable(server)
end


local map_keys = require("config.utils").map_keys

-- Diagnóstico LSP
-----------------------------------------------------------------------
local diagnostic_maps = {
    { "n", "<leader>d", function() vim.diagnostic.open_float(nil, { focus = false, border = "rounded" }) end,
        { desc = "Mostrar diagnóstico atual (LSP)" } },

    { "n", "[d", vim.diagnostic.goto_prev, { desc = "Ir para diagnóstico anterior" } },
    { "n", "]d", vim.diagnostic.goto_next, { desc = "Ir para próximo diagnóstico" } },
    { "n", "<leader>dl", vim.diagnostic.setloclist, { desc = "Abrir lista de diagnósticos" } },
}

--------------------------------------------------------------------------------
--  Mapeamentos de Diagnóstico (LSP)
-- Este segundo bloco faz o mesmo processo para atalhos relacionados ao LSP,
-- aplicando comandos de diagnóstico (erros, avisos, lista de diagnósticos, etc).
--
-- Estrutura:
--   - Cada item em `diagnostic_maps` contém:
--       1️⃣ modo (sempre 'n' - modo normal)
--       2️⃣ tecla ou combinação de teclas (ex: "<leader>d")
--       3️⃣ função ou comando executado
--       4️⃣ tabela de opções (com descrição)
--------------------------------------------------------------------------------
---
for _, map in ipairs(diagnostic_maps) do             -- Percorre todos os atalhos LSP
    map_keys(map[1], map[2], map[3], map[4])         -- Aplica o mapeamento de diagnóstico
end

-----------------------------------------------------------------------
--  Navegação de Definições (LSP)
-- 
-- Este bloco define atalhos práticos para navegar entre símbolos de código
-- usando o protocolo LSP (Language Server Protocol).
--
-- Cada comando abre o destino em um split horizontal para preservar o
-- contexto atual do arquivo. Ideal para inspeção rápida de código.
--
-- Atalhos disponíveis:
--   • gD   → Ir para definição do símbolo
--   • gI   → Ir para implementação
--   • gDec → Ir para declaração
--   • gR   → Listar referências
--   • gT   → Mostrar tipo da definição
-----------------------------------------------------------------------

local lsp_navigation_maps = {
    -- Ir para a definição da função, variável ou classe sob o cursor
    { "n", "gD", function() vim.cmd("split") vim.lsp.buf.definition() end, { desc = "Ir para Definição (LSP)" } },

    -- Ir para a implementação (útil em linguagens orientadas a objetos)
    { "n", "gI", function() vim.cmd("split") vim.lsp.buf.implementation() end, { desc = "Ir para Implementação (LSP)" } },

    -- Ir para a declaração original (ex: tipo ou variável global)
    { "n", "gDec", function() vim.cmd("split") vim.lsp.buf.declaration() end, { desc = "Ir para Declaração (LSP)" } },

    -- Listar todas as referências ao símbolo atual
    { "n", "gR", function() vim.cmd("split") vim.lsp.buf.references() end, { desc = "Listar Referências (LSP)" } },

    -- Mostrar o tipo associado à definição (ex: struct, classe, etc.)
    { "n", "gT", function() vim.cmd("split") vim.lsp.buf.type_definition() end, { desc = "Mostrar Tipo da Definição (LSP)" } },
}

-----------------------------------------------------------------------
-- ⚙️ Aplicação dos mapeamentos definidos acima
-- 
-- Usa a função utilitária `map_keys` para registrar cada atalho com
-- comportamento consistente, modo normal e descrição.
-----------------------------------------------------------------------

for _, map in ipairs(lsp_navigation_maps) do
    map_keys(map[1], map[2], map[3], map[4])
end

