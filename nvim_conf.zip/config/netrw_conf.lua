-- lua/conf/netrw_conf.lua

--[[
================================================================================
Configurações do Netrw via Tabela
================================================================================
Descrição:
Configura o comportamento do explorador de arquivos Netrw de forma organizada.
Todas as opções são aplicadas de maneira programática usando uma tabela.
================================================================================
]]

-- Tabela contendo todas as opções do Netrw
local netrw_opts = {
    netrw_bufsettings       = 'noma nomod nu nowrap ro nobl', -- Configurações do buffer
    netrw_keepdir           = 0,                               -- Não mantém o diretório atual ao navegar
    netrw_banner            = 0,                               -- Oculta banner
    netrw_liststyle         = 3,                               -- Exibe arquivos em estilo árvore
    netrw_browse_split      = 4,                               -- Abre arquivos em nova janela
    netrw_winsize           = 80,                              -- Tamanho da janela
    netrw_altv              = 1,                               -- Força splits verticais
    netrw_alto              = 0,                               -- Desativa splits horizontais
    netrw_preview           = 1,                               -- Habilita pré-visualização
    netrw_special_syntax    = 1,                               -- Habilita syntax highlighting
    netrw_localcopydircmd   = 'cp -r',                         -- Comando padrão para copiar diretórios
}

-- Loop para aplicar todas as opções do Netrw
for k, v in pairs(netrw_opts) do 
    vim.g[k] = v
end
-- Explicação:
-- 'pairs' percorre cada chave e valor da tabela 'netrw_opts' e aplica a configuração
-- correspondente via 'vim.g', evitando repetição de múltiplas linhas 'g.opcao = valor'.


